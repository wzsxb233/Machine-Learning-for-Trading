from agent.TradingAgent import TradingAgent
import pandas as pd
import numpy as np
import os
from contributed_traders.util import get_file

class ydeng335_DevonRex(TradingAgent):
    """
    Simple Trading Agent that compares the past mid-price observations and places a
    buy limit order if the first window mid-price exponential average >= the second window mid-price exponential average or a
    sell limit order if the first window mid-price exponential average < the second window mid-price exponential average
    """

    def __init__(self, id, name, type, symbol, starting_cash,
                min_size, max_size, wake_up_freq='60s',
                log_orders=False, random_state=None, mean_valuation=100, std_valuation=10):

        super().__init__(id, name, type, starting_cash=starting_cash, log_orders=log_orders, random_state=random_state)
        self.symbol = symbol
        self.min_size = min_size  # Minimum order size
        self.max_size = max_size  # Maximum order size
        self.size = self.random_state.randint(self.min_size, self.max_size)
        self.wake_up_freq = wake_up_freq
        self.mid_list, self.avg_win1_list, self.avg_win2_list = [], [], []
        self.log_orders = log_orders
        self.state = "AWAITING_WAKEUP"
        self.price_history = []
        self.qty_history = []
        # Initialize histories
        self.trade_executed=0
        # Initialize Bayesian parameters
        self.mean_valuation = mean_valuation
        self.std_valuation = std_valuation
        self.mean_qty = 0
        # Initialize Bayesian posterior parameters
        self.posterior_mean = mean_valuation
        self.posterior_std = std_valuation


    def kernelStarting(self, startTime):
        super().kernelStarting(startTime)
        # Read in the configuration through util
        with open(get_file('ydeng335_DevonRex/DevonRex.cfg'), 'r') as f:
            self.window1, self.window2 = [int(w) for w in f.readline().split()]
        #print(f"{self.window1} {self.window2}")




    def bayesian_update(self):
        # Get the latest price and quantities
        bid, bid_qty, ask, ask_qty = self.getKnownBidAsk(self.symbol)
        latest_price = (bid + ask) / 2 if bid and ask else 0
        latest_qty = bid_qty + ask_qty

        # If there's no price data, we can't update our beliefs
        if latest_price == 0:
            return

        # Add the latest price and quantity to the history
        self.price_history.append(latest_price)
        self.qty_history.append(latest_qty)

        # Calculate the likelihood mean and std (based on the historical prices)
        likelihood_mean = np.mean(self.price_history)
        likelihood_std = np.std(self.price_history)

        # Now we perform a standard Bayesian update
        epsilon = 1e-8  # A small constant

        self.posterior_mean = ((likelihood_mean / (likelihood_std**2 + epsilon)) + (self.mean_valuation / (self.std_valuation**2 + epsilon))) / (1 / (likelihood_std**2 + epsilon) + 1 / (self.std_valuation**2 + epsilon))

        self.posterior_std = np.sqrt(1 / ((1 / (likelihood_std**2 + epsilon)) + (1 / (self.std_valuation**2 + epsilon))))

        # Update our beliefs (the "actual" mean and std dev)
        self.mean_valuation = likelihood_mean
        self.std_valuation = likelihood_std

        # Use the historical quantities to calculate an average order quantity
        self.mean_qty = np.mean(self.qty_history)




    def get_bbp(self):
        """Calculate Bollinger Band Percent"""
        # Compute moving average and standard deviation
        moving_avg = np.mean(self.mid_list[-self.window2:]) if len(self.mid_list) >= self.window2 else 0
        moving_std = np.std(self.mid_list[-self.window2:]) if len(self.mid_list) >= self.window2 else 0

        # Compute Bollinger Bands
        upper_band = moving_avg + 2 * moving_std
        lower_band = moving_avg - 2 * moving_std

        # Compute Bollinger Band Percent
        bbp = (self.mid_list[-1] - lower_band) / (upper_band - lower_band) if upper_band != lower_band else 0.5  # If upper band == lower band, bbp is 0.5

        return bbp


    def get_bayesian_signal(self, currentTime):
        """Generate trading signals based on the Bayesian posterior estimates and the current price, with added emphasis on BBP"""
        self.bayesian_update()  # Update beliefs before generating signal

        # Get Bollinger Band Percent
        bbp = self.get_bbp()

        # Get time to market close
        dt = (self.mkt_close - currentTime) / np.timedelta64(1, 'm')

        # Convert Timedelta to float (number of minutes)
        market_duration = (self.mkt_close - self.mkt_open).total_seconds() / 60

        # Compute decay factor based on time to market close
        decay_factor = dt / market_duration

        # Get current mid price and quantities
        bid, bid_qty, ask, ask_qty = self.getKnownBidAsk(self.symbol)
        mid_price = (bid + ask) / 2 if bid and ask else 0
        current_qty = bid_qty + ask_qty

        # Determine probabilities for each action
        p_buy = np.clip(self.posterior_mean / mid_price, 0, 1) * bbp if mid_price != 0 else 0
        p_sell = (1 - p_buy) * (1 - bbp)

        # Adjust probabilities based on BBP, decay factor, posterior std, and order quantity
        if bbp < 0.5 and self.posterior_std < self.std_valuation and current_qty > self.mean_qty:
            p_buy *= 1.1  # increase buy probability
        elif bbp > 0.5 and self.posterior_std > self.std_valuation and current_qty < self.mean_qty:
            p_sell *= 1.1  # increase sell probability
        if decay_factor < 0.5:
            p_sell *=1.1  # increase sell probability
        # Normalize the probabilities so they sum to 1
        total_prob = p_buy + p_sell
        p_buy /= total_prob
        p_sell /= total_prob

        # Add a 50% chance to output 'HOLD'
        action = np.random.choice(['BUY', 'SELL', 'HOLD'], p=[p_buy/2, p_sell/2, 0.5])
        dt = (self.mkt_close - currentTime) / np.timedelta64(1, 'm')
        if dt < 0.65:
            return 'HIGH SELL'
        return action





        
    def wakeup(self, currentTime):
        """ Agent wakeup is determined by self.wake_up_freq """
        can_trade = super().wakeup(currentTime)
        if not can_trade: return
        self.getCurrentSpread(self.symbol)
        self.state = 'AWAITING_SPREAD'

    def dump_shares(self):
        # get rid of any outstanding shares we have
        if self.symbol in self.holdings and len(self.orders) == 0:
            order_size = self.holdings[self.symbol]
            bid, _, ask, _ = self.getKnownBidAsk(self.symbol)
            if bid:
                self.placeLimitOrder(self.symbol, quantity=order_size, is_buy_order=False, limit_price=0)

    def receiveMessage(self, currentTime, msg):
        """ Momentum agent actions are determined after obtaining the best bid and ask in the LOB """
        super().receiveMessage(currentTime, msg)
        if self.state == 'AWAITING_SPREAD' and msg.body['msg'] == 'QUERY_SPREAD':
            dt = (self.mkt_close - currentTime) / np.timedelta64(1, 'm')
            if dt < 0.35:
                self.dump_shares()
            else:
                bid, _, ask, _ = self.getKnownBidAsk(self.symbol)
                if bid and ask:
                    self.mid_list.append((bid + ask) / 2)
                    if len(self.mid_list) > self.window1: self.avg_win1_list.append(pd.Series(self.mid_list).ewm(span=self.window1).mean().values[-1].round(2))
                    if len(self.mid_list) > self.window2: self.avg_win2_list.append(pd.Series(self.mid_list).ewm(span=self.window2).mean().values[-1].round(2))
                    if len(self.avg_win1_list) > 0 and len(self.avg_win2_list) > 0 and len(self.orders) == 0:
                        if self.avg_win1_list[-1] >= self.avg_win2_list[-1]:
                            # Check that we have enough cash to place the order
                            if self.holdings['CASH'] >= (self.size * ask):
                                self.placeLimitOrder(self.symbol, quantity=self.size, is_buy_order=True, limit_price=ask)
                        else:
                            if self.symbol in self.holdings and self.holdings[self.symbol] > 0:
                                order_size = min(self.size, self.holdings[self.symbol])
                                self.placeLimitOrder(self.symbol, quantity=order_size, is_buy_order=False, limit_price=bid-1)

                    # Independent logic using Bayesian signal
                    else:
                        bayesian_signal = self.get_bayesian_signal(currentTime)
                        if bayesian_signal == 'BUY' and self.holdings['CASH'] >= (self.min_size * ask):
                            # Check that we have enough cash to place the order
                            self.placeLimitOrder(self.symbol, quantity=self.min_size, is_buy_order=True, limit_price=ask)
                        elif bayesian_signal == 'SELL' and self.symbol in self.holdings and self.holdings[self.symbol] >= self.min_size:
                            # Check that we have enough shares to place the order
                            self.placeLimitOrder(self.symbol, quantity=self.min_size, is_buy_order=False, limit_price=bid-1)
                        elif bayesian_signal == 'HIGH SELL': #and self.symbol in self.holdings and self.holdings[self.symbol] > 0:
                            order_size = min(self.size, self.holdings[self.symbol])
                            self.placeLimitOrder(self.symbol, quantity=order_size, is_buy_order=False, limit_price=bid-1)

            self.setWakeup(currentTime + self.getWakeFrequency())
            self.state = 'AWAITING_WAKEUP'


    def orderExecuted(self, order):
        super().orderExecuted(order)  # Call the parent class's method
        self.trade_executed += 1  # Then increment your new attribute


    def getWakeFrequency(self):
        return pd.Timedelta(self.wake_up_freq)

    def author():
        return 'ydeng335'
    
    def agentname():
        return 'ydeng335_DevonRex'
    
    def number_of_counting(self):
        return self.trade_executed