ydeng335_DevonRex Trading Agent
-------------------------------

The ydeng335_DevonRex trading agent is a Bayesian-based agent that operates in a limit order book environment. It generates trading signals based on Bayesian posterior estimates and the current price. 

The main steps in the agent's operation are as follows:

1. Bayesian Update: At each timestep, the agent updates its beliefs about the mean and standard deviation of the security price using a Bayesian update. The likelihood is based on the historical prices. 

2. Bollinger Band Percent (BBP): The agent calculates the BBP, which measures where the last price falls in relation to the Bollinger Bands. The bands are 2 standard deviations away from a moving average.

3. Generate Trading Signal: Based on the Bayesian posterior estimates and the BBP, the agent determines probabilities for each action (buy, sell, hold). The BBP and other factors such as decay factor, posterior standard deviation, and order quantity are used to adjust these probabilities. 

4. Trade Execution: If the trading signal is 'BUY' and the agent has enough cash, it places a buy limit order. If the signal is 'SELL' and the agent has enough shares, it places a sell limit order. The agent also has a 'HOLD' action which can be selected with a 50% chance to not interfere with the original strategy.

The agent also has a separate logic that uses the momentum of two exponential moving averages of different windows to generate a trading signal. If the average of the shorter window is greater than the average of the longer window, the agent will place a buy order; otherwise, it will place a sell order.

Note: This agent prioritizes the momentum strategy and uses the Bayesian signal as supplementary information to make decisions.
