#!/bin/bash

python -u abides.py -c sparse_zi_1000 -l sparse_zi_1000 -b 'all' -s 123456789
