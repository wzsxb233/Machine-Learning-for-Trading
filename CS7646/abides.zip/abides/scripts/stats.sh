python cli/stats.py "$(ls -atd log/15* | head -n 1)"
