#!/bin/bash

config=rmsc01
log=rmsc01

# Define a list of seeds
seeds="91011"

if [ $# -eq 0 ]; then
    for seed in $seeds; do
        python -u abides.py -c $config -l $log -s $seed 
    done
else
    agent=$1
    for seed in $seeds; do
        python -u abides.py -c $config -l $log -s $seed -a $agent 
    done
fi
