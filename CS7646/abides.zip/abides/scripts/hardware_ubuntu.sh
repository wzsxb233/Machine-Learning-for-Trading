#!/bin/bash

sudo lshw
