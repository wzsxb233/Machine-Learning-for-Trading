python cli/book_plot.py "$(ls -at log/15*/order* | head -n 1)"
