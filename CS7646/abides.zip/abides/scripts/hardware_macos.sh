#!/bin/bash

system_profiler SPHardwareDataType
