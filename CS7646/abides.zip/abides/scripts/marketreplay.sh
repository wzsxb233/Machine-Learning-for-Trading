#!/bin/bash

python -u abides.py -c marketreplay -l marketreplay -s 123456789